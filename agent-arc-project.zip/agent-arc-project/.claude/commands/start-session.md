# Start Session

Use this before meaningful work in the ARC repo.

## Checklist

1. Read `INDEX.md`
2. Read `MEMORY.md`
3. Read `CLAUDE.md`
4. Read only the relevant spec docs for the task
5. Identify whether this task affects:
   - format
   - builder
   - loader
   - trust model
   - evaluation
6. Decide whether an ADR update is needed

## Output expected from Claude

- current understanding of task scope
- impacted files
- assumptions being used
- any architecture risk to watch


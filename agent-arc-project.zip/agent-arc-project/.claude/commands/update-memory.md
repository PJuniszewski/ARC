# Update Memory

Use after meaningful repo work.

## Update fields

- current stage
- accepted direction changes
- new open questions
- closed questions
- next tasks
- risks that increased or decreased

## Rule

Keep `MEMORY.md` concise.
Do not turn it into a changelog graveyard.

